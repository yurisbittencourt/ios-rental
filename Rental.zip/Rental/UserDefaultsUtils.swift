import Foundation

struct UserDefaultsUtils {
    
    static func getProperties() -> [Property] {
        var properties: [Property] = []
        
        if let data = UserDefaults.standard.data(forKey: "PROPERTIES") {
            do {
                properties = try JSONDecoder().decode([Property].self, from: data)
            } catch {
                print(">>> ERROR: not possivel to recover the property array: \(error.localizedDescription)")
            }
        } else {
            do {
                let data = try JSONEncoder().encode(properties)
                UserDefaults.standard.set(data, forKey: "PROPERTIES")
            } catch {
                print(">>> ERROR: Can not set a new property array, \(error.localizedDescription)")
            }
        }
        
        print(">>> INFO: Properties returned successfully")
        return properties
    }
    
    static func getPropertyById(id: String) -> Property {
        let properties: [Property] = getProperties()
        
        if let index = properties.firstIndex(where: { $0.id == id }) {
            return properties[index]
        }
        
        return properties[0]
    }
    
    static func insertProperty(property: Property) {
        var properties: [Property] = getProperties()
        
        properties.append(property)
        
        do {
            let data = try JSONEncoder().encode(properties)
            UserDefaults.standard.set(data, forKey: "PROPERTIES")
            print(">>> INFO: Properties saved successfully!")
        } catch {
            print(">>> ERROR: Error saving property: \(property.id), \(error.localizedDescription)")
        }
    }
    
    static func updateProperty(property: Property) {
        var properties: [Property] = getProperties()
        
        if let index = properties.firstIndex(where: { $0.id == property.id }) {
            properties[index] = property
            
            do {
                let data = try JSONEncoder().encode(properties)
                UserDefaults.standard.set(data, forKey: "PROPERTIES")
                
                print(">>> INFO: Properties updated successfully!")
            } catch {
                print(">>> ERROR: Error updating property: \(property.id), \(error.localizedDescription)")
            }
        }
    }
    
    static func deleteProperty(property: Property) {
        var properties: [Property] = getProperties()
        
        if let index = properties.firstIndex(where: { $0.id == property.id }) {
            properties.remove(at: index)
            
            do {
                let data = try JSONEncoder().encode(properties)
                UserDefaults.standard.set(data, forKey: "PROPERTIES")
                print(">>> INFO: Properties deleted successfully!")
            } catch {
                print(">>> ERROR: Error deleting property: \(property.id), \(error.localizedDescription)")
            }
        }
    }
    
    static func getUser(email: String, password: String) -> User? {
        guard let userData = UserDefaults.standard.data(forKey: "USERS") else {
            print(">>> ERROR: User data not found in UserDefaults")
            return nil
        }
        do {
            let users = try JSONDecoder().decode([User].self, from: userData)
            
            if let user = users.first(where: { $0.email == email }) {
                if user.password == password {
                    return user
                } else {
                    print(">>> ERROR: Wrong password")
                }
            } else {
                print(">>> INFO: User not found")
            }
        } catch {
            print(">>> ERROR: Failed to decode user data: \(error.localizedDescription)")
        }
        return nil
    }
    
    static func saveUser(user: User) {
        do {
            // Fetch existing user data from UserDefaults
            if let userData = UserDefaults.standard.data(forKey: "USERS") {
                // Decode existing user data into an array of users
                var users = try JSONDecoder().decode([User].self, from: userData)
                
                // Append the new user to the array
                users.append(user)
                
                // Save the updated array back to UserDefaults
                let encodedUsers = try JSONEncoder().encode(users)
                UserDefaults.standard.set(encodedUsers, forKey: "USERS")
            } else {
                // No existing user data found, create a new array with the new user
                let encodedUsers = try JSONEncoder().encode([user])
                UserDefaults.standard.set(encodedUsers, forKey: "USERS")
            }
            
            // Print success message
            print(">>> INFO: User saved successfully. \nUser: \(user)")
        } catch {
            // Handle errors
            print(">>> ERROR: \(error.localizedDescription)")
        }
    }
}
