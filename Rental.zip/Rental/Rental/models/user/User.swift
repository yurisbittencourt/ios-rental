import Foundation

struct User: Codable {
    var id: String
    var name: String
    var email: String
    var password: String
    var phone: String
    var type: String
    var favoritedProperties: [Property]
    var ownedProperties: [Property]
    
    init(
        name: String,
        email: String,
        password: String,
        phone: String,
        type: String,
        favoritedProperties: [Property],
        ownedProperties: [Property]) {
            self.id = UUID().uuidString
            self.name = name
            self.email = email
            self.password = password
            self.phone = phone
            self.type = type
            self.favoritedProperties = favoritedProperties
            self.ownedProperties = ownedProperties
        }
    
    init() {
        self.id = "id"
        self.name = "Guest"
        self.email = "N/A"
        self.password = "N/A"
        self.phone = "N/A"
        self.type = UserTypeEnum.GUEST.rawValue
        self.favoritedProperties = []
        self.ownedProperties = []
    }
}

enum UserTypeEnum: String, CaseIterable {
    case GUEST
    case TENANT
    case LANDLORD
}
