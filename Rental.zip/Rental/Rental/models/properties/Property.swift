import Foundation

class Property: Codable, Hashable, Identifiable {
   
    var id: String
    var title: String
    var type: String
    var owner: String
    var bedroom: Int
    var bathroom: Int
    var kitchen: Int
    var closet: Int
    var laundry: Int
    var livingRoom: Int
    var balcony: Int
    var squareFeet: Double
    var rent: Double
    var propertyDescription: String
    var address: String
    var city: String
    var postalCode: String
    var isRent: Bool
    var additionalInformation: String
    //    var coordinates: CLLocationCoordinate2D
    
    init(
        id: String,
        title: String,
        type: String,
        owner: String,
        bedroom: Int,
        bathroom: Int,
        kitchen: Int,
        closet: Int,
        laundry: Int,
        livingRoom: Int,
        balcony: Int,
        squareFeet: Double,
        rent: Double,
        propertyDescription: String,
        address: String,
        city: String,
        postalCode: String,
        isRent: Bool,
        additionalInformation: String) {
            self.id = id == "" ? UUID().uuidString : id
            self.title = title
            self.type = type
            self.owner = owner
            self.bedroom = bedroom
            self.bathroom = bathroom
            self.kitchen = kitchen
            self.closet = closet
            self.laundry = laundry
            self.livingRoom = livingRoom
            self.balcony = balcony
            self.squareFeet = squareFeet
            self.rent = rent
            self.propertyDescription = propertyDescription
            self.address = address
            self.city = city
            self.postalCode = postalCode
            self.isRent = isRent
            self.additionalInformation = additionalInformation
        }
    
    static func getEmptyProperty() -> Property {
        return Property(
            id: "",
            title: "",
            type: PropertyTypeEnum.APARTMENT.rawValue,
            owner: "",
            bedroom: 0,
            bathroom: 0,
            kitchen: 0,
            closet: 0,
            laundry: 0,
            livingRoom: 0,
            balcony: 0,
            squareFeet: 0.0,
            rent: 0.0,
            propertyDescription: "",
            address: "",
            city: "",
            postalCode: "",
            isRent: true,
            additionalInformation: ""
        )
    }
    
    static func getEnum(value : String) -> PropertyTypeEnum {
        if let index = PropertyTypeEnum.allCases.firstIndex(where: { $0.rawValue == value }) {
            return PropertyTypeEnum.allCases[index]
        }
        
        return .APARTMENT
    }
    
    static func == (lhs: Property, rhs: Property) -> Bool {
        return lhs.id == rhs.id
    }
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

enum PropertyTypeEnum: String, CaseIterable {
    case APARTMENT
    case HOUSE
    case CONDO
    case TOWNHOUSE
}
