import SwiftUI

struct Favorites: View {
    @EnvironmentObject var current: Current
    
    var body: some View {
        if current.user.name == "Guest" {
            Login()
        } else {
            NavigationStack {
                List {
                    ForEach(current.user.favoritedProperties) { property in
                        NavigationLink(destination: RentalDetails()) {
                            VStack(alignment: .leading) {
                                Text(property.title)
                                Text(String(property.rent))
                            }
                        }
                    }
                    .onDelete(perform: removeFavorite)
                }
                .navigationBarTitle("Property Listings")
            }
        }
    }
    
    func removeFavorite(at offsets: IndexSet) {
        current.user.favoritedProperties.remove(atOffsets: offsets)
    }
}
