import SwiftUI

struct RentalDetails: View {
    
    @EnvironmentObject var current: Current
    
    @State private var isShowingDetailView = false
    @State private var navigateToSave = false
    
    var body: some View {
        NavigationView{
            VStack {
                HStack {
                    Spacer()
                    Text("Rental Detail")
                        .font(.title)
                        .bold()
                    Spacer()
                }
                
                Form{
                    Text("Ad Title: \(current.property.title)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Rent ($ CAD): \(current.property.rent)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Property Type: \(current.property.type)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Bedroom: \(current.property.bedroom)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Bedroom: \(current.property.bedroom)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Bathroom: \(current.property.bathroom)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Kitchen: \(current.property.kitchen)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Closet: \(current.property.closet)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Laundry: \(current.property.laundry)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Living Room: \(current.property.livingRoom)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Balcony: \(current.property.balcony)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Square Feet: \(current.property.squareFeet)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Address: \(current.property.address)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("ZIP Code: \(current.property.postalCode)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("City: \(current.property.city)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Description: \(current.property.propertyDescription)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                    
                    Text("Additional Information: \(current.property.additionalInformation)")
                        .font(.subheadline)
                        .bold()
                        .padding(.horizontal, 10)
                }
                
                if current.user.type != UserTypeEnum.GUEST.rawValue {
                    HStack {
                        Spacer()
                        Button("Add to favorites"){
                            current.user.favoritedProperties.append(current.property)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 20)
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .background(Color.black)
                        Spacer()
                    }
                }
                
                if (current.user.ownedProperties.first(where: {$0.id == current.property.id}) != nil) {
                    HStack {
                        Spacer()
                        NavigationLink(destination: RentalSave(mode: "update"), isActive: $navigateToSave){ EmptyView() }
                        Button("Update"){
                            current.setProperty(current.property)
                            navigateToSave = true
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 10)
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                        .background(Color.black)
                        Spacer()
                    }
                }
                Spacer()
            }
        }
    }
}
