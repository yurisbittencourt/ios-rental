//
//  RentalSave.swift
//  Rental
//
//  Created by Rafael Turse on 2024-02-14.
//

import SwiftUI

struct RentalSave: View {
    
    @EnvironmentObject var current: Current
    
    @State private var title: String = ""
    @State private var rent: String = ""
    @State private var type = PropertyTypeEnum.APARTMENT.rawValue
    @State private var owner: String = ""
    @State private var bedroom: String = "0"
    @State private var bathroom: String = "0"
    @State private var kitchen: String = "0"
    @State private var closet: String = "0"
    @State private var laundry: String = "0"
    @State private var livingRoom: String = "0"
    @State private var balcony: String = "0"
    @State private var squareFeet: String = "0"
    @State private var propertyDescription: String = ""
    @State private var address: String = ""
    @State private var city: String = ""
    @State private var postalCode: String = ""
    @State private var isRent: Bool = true
    @State private var additionalInformation: String = ""
    @State private var saveSuccessAlert = false
    
    var mode: String = ""
        
    var body: some View {
        NavigationStack{
            VStack {
                HStack {
                    Spacer()
                    Text("Rental")
                        .font(.title)
                        .bold()
                    Spacer()
                }
                                
                Form {
                    Section(header: Text("Ad Title:")){
                        TextField("Enter the rental ad title", text: $title)
                    }
                    
                    Section(header: Text("Rent ($ CAD):")){
                        TextField("Enter the rent value ($ CAD)", text: $rent)
                    }
                    
                    Section(header: Text("Property Type")) {
                        Picker(selection: $type, label: Text("Property Type")) {
                            ForEach(PropertyTypeEnum.allCases, id: \.self) { propertyType in
                                Text(propertyType.rawValue).tag(propertyType.rawValue)
                            }
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 20) {
                        HStack {
                            VStack {
                                Text("Bedroom")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $bedroom)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 60)
                            }
                            
                            VStack {
                                Text("Bathroom")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $bathroom)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 60)
                            }
                            
                            VStack {
                                Text("Kitchen")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $kitchen)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 60)
                            }
                            
                            VStack {
                                Text("Closet")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $closet)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 60)
                            }
                        }
                        
                        HStack {
                            VStack {
                                Text("Laundry")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $laundry)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 64)
                            }
                            
                            VStack {
                                Text("Living Room")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $livingRoom)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 64)
                            }
                            
                            VStack {
                                Text("Balcony")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $balcony)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 64)
                            }
                            
                            VStack {
                                Text("Square Feet")
                                    .font(.callout)
                                    .frame(height: 50)
                                TextField("0", text: $squareFeet)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .keyboardType(.numberPad)
                                    .frame(width: 64)
                            }
                        }
                    }
                    
                    Section(header: Text("Address:")){
                        TextField("Enter the rental address", text: $address)
                    }
                    
                    Section(header: Text("ZIP Code:")){
                        TextField("Enter the ZIP code", text: $postalCode)
                    }
                    
                    Section(header: Text("City:")){
                        TextField("Enter the city", text: $city)
                    }
                    
                    Section(header: Text("Description:")){
                        TextField("Enter the rental description", text: $propertyDescription)
                    }
                    
                    Section(header: Text("Additional Information:")){
                        TextField("Enter the rental additional information", text: $additionalInformation)
                    }
                }
                
                HStack {
                    Spacer()
                    Button("Save") {
                        save()
                        saveSuccessAlert = true
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 10)
                    .foregroundColor(.white)
                    .fontWeight(.bold)
                    .background(Color.black)
                    .alert(isPresented: $saveSuccessAlert) {
                        Alert(title: Text("Success!"), message: Text("Rental saved!"), dismissButton: .default(Text("OK")))
                    }
                    Spacer()
                }
                Spacer()
            }
        }
        .onAppear {
            setMode()
        }
    }
        
    func setMode() {
        if (mode == "update") {            
            title = current.property.title
            type = current.property.type
            owner = current.property.owner
            bedroom = String(current.property.bedroom)
            bathroom = String(current.property.bathroom)
            kitchen = String(current.property.kitchen)
            closet = String(current.property.closet)
            laundry = String(current.property.laundry)
            livingRoom = String(current.property.livingRoom)
            balcony = String(current.property.balcony)
            squareFeet = String(current.property.squareFeet)
            rent = String(current.property.rent)
            propertyDescription = current.property.propertyDescription
            address = current.property.address
            city = current.property.city
            postalCode = current.property.postalCode
            isRent = current.property.isRent
            additionalInformation = current.property.additionalInformation
        }
    }
    
    func assembleProperty(id: String) -> Property {
        return Property(
            id: id,
            title: title,
            type: type,
            owner: owner,
            bedroom: Int(bedroom) ?? 0,
            bathroom: Int(bathroom) ?? 0,
            kitchen: Int(kitchen) ?? 0,
            closet: Int(closet) ?? 0,
            laundry: Int(laundry) ?? 0,
            livingRoom: Int(livingRoom) ?? 0,
            balcony: Int(balcony) ?? 0,
            squareFeet: Double(squareFeet) ?? 0.0,
            rent: Double(rent) ?? 0.0,
            propertyDescription: propertyDescription,
            address: address,
            city: city,
            postalCode: postalCode,
            isRent: true,
            additionalInformation: additionalInformation
        )
    }
    
    func reset() {
        title = ""
        rent = ""
        type = PropertyTypeEnum.APARTMENT.rawValue
        owner = ""
        bedroom = "0"
        bathroom = "0"
        kitchen = "0"
        closet = "0"
        laundry = "0"
        livingRoom = "0"
        balcony = "0"
        squareFeet = "0"
        propertyDescription = ""
        address = ""
        city = ""
        postalCode = ""
        isRent = true
        additionalInformation = ""
    }
    
    func save() {
        if (mode == "insert") {
            current.setProperty(assembleProperty(id: ""))
            current.user.ownedProperties.append(current.property)
            reset()
        } else if (mode == "update") {
            current.setProperty(assembleProperty(id: current.property.id))
           
            if let index = current.user.ownedProperties.firstIndex(where: { $0.id == current.property.id }){
                current.user.ownedProperties[index] = current.property
            }
        }
    }
}
