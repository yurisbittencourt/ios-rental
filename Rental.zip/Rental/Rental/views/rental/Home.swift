import SwiftUI

struct Home: View {
    @EnvironmentObject var current: Current
    @EnvironmentObject var mockData: MockData
    @State private var navigateToDetails = false
    @State private var goToLogin = false

    
    var body: some View {
        NavigationView {
            List(mockData.properties){ property in
                VStack(alignment: .leading) {
                    Section {
                        Text(property.title)
                        Text(String(property.rent))
                        Button(""){
                            current.setProperty(property)
                            navigateToDetails = true
                        }
                        
                        NavigationLink(destination: RentalDetails(), isActive: $navigateToDetails){ EmptyView() }
                    }
                }
            }
            .navigationBarTitle("Property Listings")
            .navigationBarItems(trailing: conditionalButton())
        }
        .sheet(isPresented: $goToLogin) {
            Login()
        }
    }
    
    func conditionalButton() -> AnyView {
        if current.user.name != "Guest" {
            return AnyView(Button(action: {current.setUser(User())}){Image(systemName: "power")})
        } else {
            return AnyView(Button(action: {goToLogin = true}){Image(systemName: "power.circle.fill")})
        }
    }
}
