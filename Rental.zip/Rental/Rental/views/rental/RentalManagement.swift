//
//  RentalManagement.swift
//  Rental
//
//  Created by Rafael Turse on 2024-02-14.
//

import SwiftUI

struct RentalManagement: View {
    @EnvironmentObject var current: Current
    @State private var properties = UserDefaultsUtils.getProperties()
    @State private var isShowingDetailView = false
    
    var body: some View {
        if current.user.name == "Guest" {
            Login()
        } else {
            NavigationStack{
                VStack {
                    HStack {
                        Spacer()
                        Text("Rental Management")
                            .font(.title)
                            .bold()
                        Spacer()
                    }
                    
                    List {
                        ForEach(current.user.ownedProperties) { property in
                            Section(){
                                NavigationLink{
                                    RentalDetails()
                                } label: {
                                    Text("Property: \(property.title) \nPrice: \(property.rent) \ntype: \(property.type)")
                                }
                            }
                        }.onDelete(perform: removeProperty)
                    }
                    Spacer()
                    
                    HStack {
                        Spacer()
                        NavigationLink(
                            destination: RentalSave(mode: "insert")) {
                                Text("Create Rental")
                                .frame(maxWidth: .infinity)
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 10)
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .background(Color.black)
                        Spacer()
                    }
                    Spacer()
                }.onAppear { refresh() }
            }
        }
    }
    
    func refresh() {
        properties = UserDefaultsUtils.getProperties()
    }
    func removeProperty(at offsets: IndexSet) {
        current.user.ownedProperties.remove(atOffsets: offsets)
    }
}

struct RentalManagement_Previews: PreviewProvider {
    static var previews: some View {
        RentalManagement()
    }
}
