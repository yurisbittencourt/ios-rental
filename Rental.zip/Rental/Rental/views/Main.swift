import SwiftUI

struct Main: View {
    
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            Favorites()
                .tabItem {
                    Label("Favorites", systemImage: "star.fill")
                }
            RentalManagement()
                .tabItem {
                    Label("Management", systemImage: "pencil.and.list.clipboard")
                }
            
        }
    }
}
    
#Preview { Main() }
