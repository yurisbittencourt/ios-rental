import SwiftUI

struct Signup: View {
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var type = UserTypeEnum.TENANT.rawValue
    @State private var name = ""
    @State private var signupAlert = false
    
    var body: some View {
        NavigationStack{
            VStack {
                TextField("Name", text: $name)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                
                TextField("Email", text: $email)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                
                Picker("Property Type", selection: $type) {
                    ForEach(UserTypeEnum.allCases.filter{$0 != .GUEST}, id: \.self) { userType in
                        Text(userType.rawValue).tag(userType.rawValue)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
                
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                
                SecureField("Confirm Password", text: $confirmPassword)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                
                Button("Sign Up") {
                    //TODO: Implement validations
                    let user = User(name: name, email: email, password: password, phone: "", type: type, favoritedProperties: [], ownedProperties: [])
                    
                    UserDefaultsUtils.saveUser(user: user)
                    
                    email = ""
                    password = ""
                    confirmPassword = ""
                    type = UserTypeEnum.GUEST.rawValue
                    name = ""
                    signupAlert = true
                    
                }
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)
                .alert(isPresented: $signupAlert) {
                    Alert(title: Text("Success!"), dismissButton: .default(Text("OK")))
                }
                
                NavigationLink(destination: Login()) {
                    Text("Already have an account? Log in")
                        .foregroundColor(.blue)
                }
                
                Spacer()
            }.padding(.horizontal)
                .navigationTitle("Sign Up")
        }.padding()
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Signup()
    }
}
