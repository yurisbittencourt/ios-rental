import SwiftUI

struct Login: View {
    @State private var email = ""
    @State private var password = ""
    @EnvironmentObject var current: Current
    
    var body: some View {
        NavigationStack {
            VStack {
                TextField("Email", text: $email)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                Button(action: {
                    //TODO: Implement validation
                    if let user = UserDefaultsUtils.getUser(email: email, password: password) {
                        current.setUser(user)
                    }
                }) {
                    Text("Login")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(10)
                .padding(.horizontal)
                
                NavigationLink(destination: Signup()) {
                    Text("Don't have an account? Sign up")
                        .foregroundColor(.blue)
                }
                Spacer()
            }
            .navigationTitle("Log In")

        }
        .padding()
    }
}
