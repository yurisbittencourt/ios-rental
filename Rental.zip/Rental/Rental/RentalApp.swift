//
//  RentalApp.swift
//  Rental
//
//  Created by Rafael Turse on 2024-02-14.
//

import SwiftUI

@main
struct RentalApp: App {
    let current = Current()
    let mockData = MockData()
    
    var body: some Scene {
        WindowGroup {
            Main()
                .environmentObject(current)
                .environmentObject(mockData)
        }
    }
}
