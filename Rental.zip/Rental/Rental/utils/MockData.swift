import Foundation

class MockData: ObservableObject {
    @Published var properties: [Property] = [
        Property(id:"", title: "Toronto HOUSE", type: PropertyTypeEnum.HOUSE.rawValue, owner: "John Smith", bedroom: 1, bathroom: 1, kitchen: 1, closet: 1, laundry: 1, livingRoom: 1, balcony: 1, squareFeet: 500, rent: 1500, propertyDescription: "Small House in Toronto", address: "1 Charles St", city: "Toronto", postalCode: "M4Y 1T5", isRent: true, additionalInformation: "Description"),
        
        Property(id:"", title: "Vancouver HOUSE", type: PropertyTypeEnum.HOUSE.rawValue, owner: "John Smith", bedroom: 1, bathroom: 1, kitchen: 1, closet: 1, laundry: 1, livingRoom: 1, balcony: 1, squareFeet: 500, rent: 1500, propertyDescription: "Small House in Toronto", address: "1 Charles St", city: "Vancouver", postalCode: "M4Y 1T5", isRent: true, additionalInformation: "Description"),
        
        Property(id:"", title: "Alberta HOUSE", type: PropertyTypeEnum.HOUSE.rawValue, owner: "John Smith", bedroom: 1, bathroom: 1, kitchen: 1, closet: 1, laundry: 1, livingRoom: 1, balcony: 1, squareFeet: 500, rent: 1500, propertyDescription: "Small House in Toronto", address: "1 Charles St", city: "Alberta", postalCode: "M4Y 1T5", isRent: true, additionalInformation: "Description"),
        
        Property(id:"", title: "Calgary HOUSE", type: PropertyTypeEnum.HOUSE.rawValue, owner: "John Smith", bedroom: 1, bathroom: 1, kitchen: 1, closet: 1, laundry: 1, livingRoom: 1, balcony: 1, squareFeet: 500, rent: 1500, propertyDescription: "Small House in Toronto", address: "1 Charles St", city: "Calgary", postalCode: "M4Y 1T5", isRent: true, additionalInformation: "Description"),
        
        Property(id:"", title: "Montreal HOUSE", type: PropertyTypeEnum.HOUSE.rawValue, owner: "John Smith", bedroom: 1, bathroom: 1, kitchen: 1, closet: 1, laundry: 1, livingRoom: 1, balcony: 1, squareFeet: 500, rent: 1500, propertyDescription: "Small House in Toronto", address: "1 Charles St", city: "Montreal", postalCode: "M4Y 1T5", isRent: true, additionalInformation: "Description")
    ]
}
