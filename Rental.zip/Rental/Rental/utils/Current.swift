import Foundation

class Current: ObservableObject {
    @Published var user: User = User()
    @Published var property: Property = Property.getEmptyProperty()
    
    func setUser(_ currentUser: User) {
        user = currentUser
    }
    
    func setProperty(_ currentProperty: Property) {
        property = currentProperty
    }
}
